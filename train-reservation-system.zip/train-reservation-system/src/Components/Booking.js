import React, { useState, useEffect } from 'react'
import { Form, Row, Col, Button, Card } from 'react-bootstrap'
import { useDispatch, useSelector } from 'react-redux'

const Booking = () => {
  const [formData, setFormData] = useState({
    name: '',
    age: '',
    coachType: '',
    train: '',
  })
  const [availableTrains, setAvailableTrains] = useState([])
  const [coachTypes, setCoachTypes] = useState([])

  const dispatch = useDispatch()
  const trains = useSelector((state) => state?.trains)

  useEffect(() => {
    let avlTrains = Object.keys(trains)
    setAvailableTrains(avlTrains)
    setCoachTypes(Object.keys(trains[avlTrains[0]]))
  }, [])

  const handleChange = (e) => {
    const name = e.target.name
    const val = e.target.value

    setFormData({ ...formData, [name]: val })
  }

  const onSubmit = (e) => {
    e.preventDefault()
    dispatch({ type: 'BOOK_TICKET', payload: formData })
  }

  return (
    <div className="booking-page container mt-4">
      <Card className="p-4">
        <h1>Book Ticket</h1>
        <Form onSubmit={onSubmit}>
          <Form.Group as={Row} className="mb-3">
            <Form.Label column sm={3}>
              Train
            </Form.Label>
            <Col>
              <Form.Select name="train" onChange={handleChange} required>
                <option value="">Select Train</option>
                {availableTrains.map((item, index) => (
                  <option key={index} value={item}>
                    {item}
                  </option>
                ))}
              </Form.Select>
            </Col>
          </Form.Group>
          <Form.Group as={Row} className="mb-3">
            <Form.Label column sm={3}>
              Name
            </Form.Label>
            <Col>
              <Form.Control
                type="text"
                name="name"
                placeholder="enter passenger name"
                onChange={handleChange}
                required
              />
            </Col>
          </Form.Group>
          <Form.Group as={Row} className="mb-3">
            <Form.Label column sm={3}>
              Age
            </Form.Label>
            <Col>
              <Form.Control
                type="number"
                name="age"
                placeholder="enter age"
                onChange={handleChange}
                required
              />
            </Col>
          </Form.Group>
          <Form.Group as={Row} className="mb-3">
            <Form.Label column sm={3}>
              Coach Type
            </Form.Label>
            <Col>
              <Form.Select name="coachType" onChange={handleChange} required>
                <option value="">Select coach type</option>
                {coachTypes.map((item, index) => (
                  <option key={index} value={item}>
                    {item}
                  </option>
                ))}
              </Form.Select>
            </Col>
          </Form.Group>

          <Button size="lg" type="submit">
            Book Now
          </Button>
        </Form>
      </Card>
    </div>
  )
}

export default Booking
