import React, { useMemo } from 'react'
import { Card } from 'react-bootstrap'

const SeatsAvailability = ({ coaches }) => {
  const coachTypes = Object.keys(coaches)
  const availability = useMemo(() => {
    let availability = {}
    console.log(coachTypes)
    coachTypes.map((coach) => {
      let coachData = coaches[coach]
      let totalSeats = coachData?.confirmed?.length
      let confirmListCount = coachData?.confirmed.filter((seat) => seat === '_')
        .length
      let waitListCount = coachData?.waitingList.filter((seat) => seat === '_')
        .length
      availability[coach] = { confirmListCount, waitListCount, totalSeats }
    })
    console.log(availability)

    return availability
  }, [])
  return (
    <div>
      {Object.keys(availability).length > 0 &&
        Object.keys(availability).map((coach) => {
          return (
            <Card className="p-4 mb-3">
              <h1 className="mb-2">{coach}</h1>
              <div className="mb-2">
                Total Seats : {availability[coach]?.totalSeats}
              </div>
              <div className="mb-2">
                Available : {availability[coach]?.confirmListCount}
              </div>
              <div className="mb-2">
                waitingList : {availability[coach]?.waitListCount}
              </div>
            </Card>
          )
        })}
    </div>
  )
}

export default SeatsAvailability
