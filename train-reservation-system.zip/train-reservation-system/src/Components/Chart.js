import React, { useState, useMemo } from 'react'
import { Button, Dropdown, Col, Table, Row } from 'react-bootstrap'
import { useDispatch, useSelector } from 'react-redux'
import SeatsAvailability from './Availability'

const Chart = () => {
  const state = useSelector((state) => state.trains)
  let trainsList = Object.keys(state)
  const [trainName, setTrainName] = useState(trainsList[0])
  const [showDetails, setShowDetails] = useState(false)

  const dispatch = useDispatch()

  const chartPrepared = useMemo(() => {
    let confirmedList = {}
    let trainData = state[trainName]

    Object.keys(trainData)?.forEach((coach) => {
      const confirmed = trainData[coach]?.confirmed.filter(
        (seat) => seat !== '_',
      )
      if (confirmed.length > 0) {
        confirmedList[coach] = confirmed
      }
    })
    return confirmedList || []
  }, [trainName, state])

  return (
    <div className="chart-page container">
      <Row className="mb-3">
        <Col className="text-start">
          <h5>{trainName}</h5>
        </Col>

        <Col className="text-end ">
          <Row className="align-items-center">
            <Col xs="auto">
              <Button onClick={() => setShowDetails(!showDetails)}>
                Check Details
              </Button>
            </Col>
            <Col xs="auto">
              <Dropdown
                onSelect={(key) => {
                  setTrainName(key)
                }}
              >
                <Dropdown.Toggle variant="success">{trainName}</Dropdown.Toggle>
                <Dropdown.Menu>
                  {trainsList.map((train) => (
                    <Dropdown.Item key={train} eventKey={train}>
                      {train}
                    </Dropdown.Item>
                  ))}
                </Dropdown.Menu>
              </Dropdown>
            </Col>
          </Row>
        </Col>
      </Row>
      <div>
        {Object.keys(chartPrepared).length > 0 && (
          <Table striped bordered hover>
            <thead>
              <tr>
                <th>Coach</th>
                <th>Passenger Name</th>
                <th>Age</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {Object.keys(chartPrepared)?.map((coach) =>
                chartPrepared[coach]?.map(({ name, age, bookingId }, index) => {
                  return (
                    <tr>
                      <td>{coach}</td>
                      <td>{name}</td>
                      <td>{age}</td>
                      <td>{bookingId}</td>
                      <td>
                        <Button
                          onClick={() => {
                            dispatch({
                              type: 'CANCEL_TICKET',
                              payload: {
                                name,
                                age,
                                coachType: coach,
                                trainName,
                              },
                            })
                          }}
                        >
                          Cancel Ticket
                        </Button>
                      </td>
                    </tr>
                  )
                }),
              )}
            </tbody>
          </Table>
        )}
      </div>
      {showDetails && <SeatsAvailability coaches={state[trainName]} />}
    </div>
  )
}

export default Chart
