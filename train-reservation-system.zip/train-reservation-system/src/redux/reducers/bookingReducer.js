import React from 'react'

export const initialState = {
  trains: {
    TRAIN_1: {
      AC: {
        confirmed: Array.from({ length: 60 }).fill('_'),
        waitingList: Array.from({ length: 10 }).fill('_'),
      },
      Sleeper: {
        confirmed: Array.from({ length: 60 }).fill('_'),
        waitingList: Array.from({ length: 10 }).fill('_'),
      },
      Seater: {
        confirmed: Array.from({ length: 60 }).fill('_'),
        waitingList: Array.from({ length: 10 }).fill('_'),
      },
    },
    TRAIN_2: {
      AC: {
        confirmed: Array.from({ length: 60 }).fill('_'),
        waitingList: Array.from({ length: 10 }).fill('_'),
      },
      Sleeper: {
        confirmed: Array.from({ length: 60 }).fill('_'),
        waitingList: Array.from({ length: 10 }).fill('_'),
      },
      Seater: {
        confirmed: Array.from({ length: 60 }).fill('_'),
        waitingList: Array.from({ length: 10 }).fill('_'),
      },
    },
  },
}
const bookingReducer = (state = initialState, action) => {
  switch (action.type) {
    case 'BOOK_TICKET': {
      const { train, coachType, name, age } = action.payload
      const confirmed = state.trains[train]?.[coachType]?.confirmed
      const waitingList = state.trains[train]?.[coachType]?.waitingList

      let avilableIndex = confirmed.findIndex((seat) => seat === '_')
      if (avilableIndex !== -1) {
        confirmed[avilableIndex] = { name, age }
        alert('Booking Successful!')
      } else {
        avilableIndex = waitingList.findIndex((seat) => seat === '_')
        if (avilableIndex !== -1) {
          waitingList[avilableIndex] = { name, age }
          alert('Booking Added to waiting List')
        } else {
          alert('Sorry! Tickets unavailable')
        }
      }

      return {
        ...state,
        trains: {
          ...state.trains,
          [train]: {
            ...state.trains[train],
            [coachType]: {
              confirmed: [...confirmed],
              waitingList: [...waitingList],
            },
          },
        },
      }
    }
    case 'CANCEL_TICKET': {
      const { trainName, coachType, name, age } = action.payload
      let confirmed = state.trains[trainName]?.[coachType].confirmed
      let waiting = state.trains[trainName]?.[coachType].waitingList
      let index = confirmed.findIndex(
        (booking) => booking.name === name && booking.age === age,
      )
      if (index !== -1) {
        let waitingPassenger
        if (waiting > 0) {
          waitingPassenger = waiting.shift()
        }
        confirmed.splice(index, 1, waitingPassenger || '_')
        alert('Booking Cancelled!')
      } else {
        alert("Booking Id doesn't exist!")
      }

      return {
        ...state,
        trains: {
          ...state.trains,
          [trainName]: {
            ...state.trains[trainName],
            [coachType]: {
              confirmed: [...confirmed],
              waitingList: [...waiting],
            },
          },
        },
      }
    }
    default:
      return state
  }
}

export default bookingReducer
