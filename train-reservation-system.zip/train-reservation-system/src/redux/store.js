import { createStore } from '@reduxjs/toolkit'
import bookingReducer from './reducers/bookingReducer'

const store = createStore(bookingReducer)

export default store