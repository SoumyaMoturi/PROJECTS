import { Nav, Navbar } from 'react-bootstrap'
import './App.css'
import Booking from './Components/Booking'
import { Routes, Route, NavLink } from 'react-router-dom'
import Chart from './Components/Chart'

function App() {
  return (
    <div className="App">
      <Navbar>
        <Nav>
          <Nav.Link as={NavLink} to="/">
            Home
          </Nav.Link>
          <Nav.Link as={NavLink} to="/chart">
            Chart
          </Nav.Link>
        </Nav>
      </Navbar>
      <Routes>
        <Route path="/" element={<Booking />} />
        <Route path="/chart" element={<Chart />} />
      </Routes>
    </div>
  )
}

export default App
